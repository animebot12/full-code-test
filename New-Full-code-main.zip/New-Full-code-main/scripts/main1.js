// TOOLS DATA - یہاں نئے ٹولز add کریں
const tools = [
    {
        name: "SMS Bomber Pro",
        desc: "Advanced bulk SMS sending platform",
        icon: "fas fa-comment-sms",
        iconClass: "sms-boomer",
        url: "tools/sms-bomber/index.html",
        comingSoon: false
    },
    {
        name: "Sim Info Tool",
        desc: "Kise bhi sim ka data check kar lo",
        icon: "fa-solid fa-sim-card",
        iconClass: "watch-time",
        url: "tools/sim-info/index.html",
        comingSoon: false
    },
    {
        name: "Sim Info Tool (2)",
        desc: "Kise bhi sim ka data check kar lo",
        icon: "fa-solid fa-sim-card",
        iconClass: "watch-time",
        url: "tools/sim-info-2/index.html",
        comingSoon: false
    },
    {
        name: "TikTok USA Account Maker",
        desc: "Create US accounts",
        icon: "fas fa-flag-usa",
        iconClass: "usa",
        url: "https://www.mediafire.com/file/4hhckbdjpqy4mwv/TikTok_USA_account_making.7z/file",
        comingSoon: false
    },
    {
        name: "TikTok Video Downloader",
        desc: "Download videos without watermark",
        icon: "fab fa-tiktok",
        iconClass: "tiktok",
        url: "tools/tiktok-downloader/index.html",
        comingSoon: false
    },
    {
        name: "Instagram Content Saver",
        desc: "Download photos, DP, reels & stories",
        icon: "fab fa-instagram",
        iconClass: "instagram",
        url: "https://toolzu.com/downloader/instagram/video/",
        comingSoon: false
    },
    {
        name: "Facebook Video Downloader",
        desc: "Download FB videos & content",
        icon: "fab fa-facebook",
        iconClass: "facebook",
        url: "https://fdownloader.net/en",
        comingSoon: false
    },
    {
        name: "YouTube HD Downloader",
        desc: "Download videos in HD quality",
        icon: "fab fa-youtube",
        iconClass: "youtube",
        url: "tools/youtube-downloader/index.html",
        comingSoon: false
    },
    {
        name: "Pinterest Image Downloader",
        desc: "Download high quality pins",
        icon: "fab fa-pinterest",
        iconClass: "pinterest",
        url: "https://klickpin.com/",
        comingSoon: false
    },
    {
        name: "AI Assistant Pro",
        desc: "Smart AI powered helper",
        icon: "fas fa-brain",
        iconClass: "ai-assistant",
        url: "tools/ai-assistant/index.html",
        comingSoon: false
    },
    {
        name: "WhatsApp Unban Service",
        desc: "Recover banned accounts",
        icon: "fab fa-whatsapp",
        iconClass: "whatsapp",
        url: "tools/whatsapp-unban/index.html",
        comingSoon: false
    },
    {
        name: "Website Attacker",
        desc: "Security testing toolkit",
        icon: "fas fa-shield-alt",
        iconClass: "security",
        url: "https://ftgm-web-attacker.vercel.app",
        comingSoon: false
    },
    {
        name: "HTML Code Encryptor",
        desc: "Encrypt HTML code securely",
        icon: "fas fa-lock",
        iconClass: "hack",
        url: "https://xmod.top/p/ftgm-html-encrypter",
        comingSoon: false
    },
    {
        name: "Fancy Text Designer",
        desc: "Create stylish text designs",
        icon: "fas fa-font",
        iconClass: "tool",
        url: "https://www.fontchanger.net/",
        comingSoon: false
    },
    {
        name: "Mod APK Store",
        desc: "Premium modded applications Use Vpn",
        icon: "fas fa-mobile-alt",
        iconClass: "apk",
        url: "https://apkdone.com/",
        comingSoon: false
    },
    {
        name: "Temporary Email Generator",
        desc: "Disposable email service",
        icon: "fas fa-envelope",
        iconClass: "email",
        url: "tools/temp-mail/index.html",
        comingSoon: false
    },
    {
        name: "Virtual Phone Number",
        desc: "Temporary phone numbers",
        icon: "fas fa-phone",
        iconClass: "phone",
        url: "tools/virtual-phone/index.html",
        comingSoon: false
    },
    {
        name: "Text to File Converter",
        desc: "Convert text to files",
        icon: "fas fa-file-code",
        iconClass: "file",
        url: "https://www.imagetotext.info/text-to-word",
        comingSoon: false
    },
    {
        name: "Whatsapp Number Hide",
        desc: "Hide your number securely",
        icon: "fas fa-user-secret",
        iconClass: "security",
        url: "#",
        comingSoon: false,
        specialFunction: "openWhatsappHide"
    },
    {
        name: "Mobile Data Restorer",
        desc: "Device recovery tools",
        icon: "fas fa-tools",
        iconClass: "restore",
        url: "https://www.mediafire.com/file/iyngfbomye8axh3/Android_reset_.apk/file",
        comingSoon: false
    },
    {
        name: "YouTube Watch Booster",
        desc: "Increase watch time",
        icon: "fas fa-clock",
        iconClass: "watch-time",
        url: "https://www.mediafire.com/file/ytwzd2kk0efzzat/YouTube_4k_Watchtime_Methid_By_AbheeBhai_Mods.zip/file",
        comingSoon: false
    },
    {
        name: "Facebook ID Ban",
        desc: "Account management tools",
        icon: "fas fa-ban",
        iconClass: "ban",
        url: "https://www.mediafire.com/file/xsy20pc3ynwamqv/Facebook_Ban_Meth_By_AbheeBhai.zip/file",
        comingSoon: false
    },
    {
        name: "Unlimited Gmail Creator",
        desc: "Create multiple accounts",
        icon: "fab fa-google",
        iconClass: "gmail",
        url: "https://www.mediafire.com/file/watf6hh6jhgx995/GMAIL_WITHOUT_PHONE_NUMBERS_.zip/file",
        comingSoon: false
    },
    {
        name: "TikTok Free Likes",
        desc: "Get unlimited Free links",
        icon: "fab fa-tiktok",
        iconClass: "tiktok",
        url: "https://zefoy.com/",
        comingSoon: false
    },
    {
        name: "Online Eraning Website",
        desc: "Eran Money Online",
        icon: "fa-solid fa-earth-oceania",
        iconClass: "ai-assistant",
        url: "tools/online-earning/index.html",
        comingSoon: false
    },
    {
        name: "Free Fire",
        desc: "Buy and Sell Fre Fire Accounts",
        icon: "fab fa-free-code-camp",
        iconClass: "tiktok",
        url: "https://tech-ai1.vercel.app/",
        comingSoon: false
    },
    // Coming Soon Tools
    {
        name: "ChatGPT Plus Tools",
        desc: "Advanced AI chat assistant",
        icon: "fas fa-comments",
        iconClass: "chatgpt",
        url: "#",
        comingSoon: true
    },
    {
        name: "Text to Image Generator",
        desc: "Generate images from text",
        icon: "fas fa-palette",
        iconClass: "text-to-image",
        url: "#",
        comingSoon: true
    },
    {
        name: "Text to Video Creator",
        desc: "Create videos from text",
        icon: "fas fa-film",
        iconClass: "text-to-video",
        url: "#",
        comingSoon: true
    },
    {
        name: "Text to Speech Converter",
        desc: "Convert text to audio",
        icon: "fas fa-volume-up",
        iconClass: "text-to-speech",
        url: "#",
        comingSoon: true
    },
    {
        name: "Phone Security Scanner",
        desc: "Security testing tool",
        icon: "fas fa-shield-virus",
        iconClass: "security",
        url: "#",
        comingSoon: true
    }
];

// Matrix Background
function createMatrix() {
    const matrixBg = document.getElementById('matrixBg');
    const chars = '01010101010101010101ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    
    for (let i = 0; i < 50; i++) {
        const code = document.createElement('div');
        code.className = 'matrix-code';
        code.textContent = chars[Math.floor(Math.random() * chars.length)];
        code.style.left = Math.random() * 100 + 'vw';
        code.style.animationDuration = (Math.random() * 10 + 5) + 's';
        code.style.animationDelay = Math.random() * 5 + 's';
        matrixBg.appendChild(code);
    }
}

// Theme Toggle - Proper Dark/Light Mode
const themeToggle = document.getElementById('themeToggle');
themeToggle.addEventListener('click', () => {
    const currentTheme = document.body.getAttribute('data-theme');
    if (currentTheme === 'light') {
        document.body.setAttribute('data-theme', 'dark');
        themeToggle.innerHTML = '<i class="fas fa-sun"></i> Light Mode';
    } else {
        document.body.setAttribute('data-theme', 'light');
        themeToggle.innerHTML = '<i class="fas fa-moon"></i> Dark Mode';
    }
});

// Display Tools
function displayTools(toolsToShow = tools) {
    const toolsGrid = document.getElementById('toolsGrid');
    toolsGrid.innerHTML = '';
    
    if (toolsToShow.length === 0) {
        toolsGrid.innerHTML = `
            <div class="not-found">
                <div class="not-found-icon">
                    <i class="fas fa-search"></i>
                </div>
                <div class="not-found-text">
                    No tools found matching your search
                </div>
            </div>
        `;
        return;
    }
    
    toolsToShow.forEach(tool => {
        const toolCard = document.createElement('div');
        toolCard.className = 'tool-card';
        
        let clickHandler = `openTool('${tool.url}')`;
        if (tool.specialFunction) {
            clickHandler = tool.specialFunction + '()';
        } else if (tool.comingSoon) {
            clickHandler = 'showComingSoon()';
        }
        
        toolCard.setAttribute('onclick', clickHandler);
        
        toolCard.innerHTML = `
            <div class="tool-icon ${tool.iconClass}"><i class="${tool.icon}"></i></div>
            <div class="tool-name">${tool.name}</div>
            <div class="tool-desc">${tool.desc}</div>
            ${tool.comingSoon ? '<div class="coming-soon-badge">Coming Soon</div>' : ''}
        `;
        
        toolsGrid.appendChild(toolCard);
    });
}

// Search Functionality
function performSearch() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase().trim();
    
    if (searchTerm === '') {
        displayTools();
        return;
    }
    
    const filteredTools = tools.filter(tool => 
        tool.name.toLowerCase().includes(searchTerm) || 
        tool.desc.toLowerCase().includes(searchTerm)
    );
    
    displayTools(filteredTools);
}

// Enter key support for search
document.getElementById('searchInput').addEventListener('keyup', function(event) {
    if (event.key === 'Enter') {
        performSearch();
    }
});

// Tool Opening Functions
function openTool(url) {
    if (url.startsWith('http')) {
        window.open(url, '_blank');
    } else {
        window.location.href = url; // Local files
    }
}

function showComingSoon() {
    alert('🚀 This tool is coming soon!\n📧 Contact us for early access');
}

function openWhatsappHide() {
    const apkLink = 'https://www.mediafire.com/file/de8hz1gsr4vq1zr/FAKE_WHATSAPP_1.0.apk/file';
    const videoLink = 'https://www.mediafire.com/file/6iyzysfys2726n1/VID-20230926-WA0000.mp4/file';
    
    if(confirm('WhatsApp Number Hide Tool\n\nAPK Download: Click OK\nVideo Tutorial: Click Cancel')) {
        window.open(apkLink, '_blank');
    } else {
        window.open(videoLink, '_blank');
    }
}

// Share Modal Functions - No Close Option
let shareModalShown = false;

function shareToolkit() {
    document.getElementById('shareModal').style.display = 'block';
    shareModalShown = true;
}

function shareSocial(platform) {
    const url = window.location.href;
    const text = 'Check out this amazing toolkit by Mr.Arslan! 30+ premium tools available.';
    
    let shareUrl = '';
    switch(platform) {
        case 'whatsapp':
            shareUrl = `https://wa.me/?text=${encodeURIComponent(text + ' ' + url)}`;
            break;
        case 'facebook':
            shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`;
            break;
        case 'twitter':
            shareUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`;
            break;
    }
    
    window.open(shareUrl, '_blank');
    // Modal automatically closes after sharing
    setTimeout(() => {
        document.getElementById('shareModal').style.display = 'none';
    }, 1000);
}

// Auto Show Share Modal after 2 minutes
setTimeout(() => {
    if (!shareModalShown) {
        shareToolkit();
    }
}, 120000);

// Prevent closing modal by clicking outside
document.getElementById('shareModal').addEventListener('click', function(e) {
    if (e.target === this) {
        // Do nothing when clicking outside
        return false;
    }
});

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    createMatrix();
    displayTools();
});
// EmailJS Configuration
emailjs.init("Wa0KRlTAbjT4PPN_g");

// Contact Form Handler
document.getElementById('contactForm').addEventListener('submit', function(e) {
  e.preventDefault();

  const name = document.getElementById('contactName').value;
  const email = document.getElementById('contactEmail').value;
  const message = document.getElementById('contactMessage').value;

  // Validation
  if (!name || !email || !message) {
    alert('Please fill in all fields.');
    return;
  }

  // Show loading state
  const submitBtn = this.querySelector('button[type="submit"]');
  const originalText = submitBtn.innerHTML;
  submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Sending...';
  submitBtn.disabled = true;

  // Send email
  emailjs.send("service_wa6q9v4", "template_z7zitf9", {
    from_name: name,
    from_email: email,
    message: message,
    to_email: 'animebot0299@gmail.com'
  })
  .then(function() {
    alert('Message sent successfully! We will contact you soon.');
    document.getElementById('contactForm').reset();
    // Close modal
    const modal = bootstrap.Modal.getInstance(document.getElementById('contactModal'));
    modal.hide();
  }, function(error) {
    alert('Failed to send message. Please try again.');
    console.error('EmailJS Error:', error);
  })
  .finally(function() {
    // Restore button
    submitBtn.innerHTML = originalText;
    submitBtn.disabled = false;
  });
});
